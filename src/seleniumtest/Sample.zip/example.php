<?PHP
phpinfo ();
?>

